<?php $infouser=datauser();?>
<?php $detuser=getdetuser($infouser['id']);
      $likol=$this->db->list_fields('user'); ?>
<script src="<?php echo base_url().'asset/js/default/jquery-1.9.1.js';?>"></script>
<script type="text/javascript">
//$(window).load(function(){
  var counter = 0;
$(document).ready(function() {
    $("#btnweb").click(function(){
    var map = {};
      $(".web").each(function() {
            map[$(this).attr("name")] = $(this).val();
      });
        var postData = {
          'namaweb' : map.namaweb,
          'website' : map.website
        };
          $.ajax({
            type: "POST",
            url: "http://localhost/toko/index.php/gudang/addweb",
            data: postData , //assign the var here 
            success: function(){
              alert( "Data berhasil ditambahkan :) ");
              location.reload();
            }
        });
    }); 

});
//});  
</script>
<script src="<?php echo base_url().'asset/js/default/jquery.min.js';?>"></script>
<script type="text/javascript">
$(document).ready(function(){
  $("#passbaru").prop('disabled', true);

});

function cekpasslama(isinya){
var x=sha1(isinya);
var y=document.getElementById("cocokpass").value;
if (x==y) {
    document.getElementById("msgcek").innerHTML="sama";
    document.getElementById("passbaru").disabled = false;
}else{
    document.getElementById("msgcek").innerHTML="tidak sama";
    document.getElementById("passbaru").disabled = true;
};
return false;
}
</script>
<style type="text/css">
.user-details {position: relative; padding: 0;}
.user-details .user-info-block {width: 100%; position: absolute; top: 55px; background: rgb(255, 255, 255); z-index: 0; padding-top: 35px;}
 .user-info-block .user-heading {width: 100%; text-align: center; margin: 10px 0 0;}
 .user-info-block .navigation {float: left; width: 100%; margin: 0; padding: 0; list-style: none; border-bottom: 1px solid #428BCA; border-top: 1px solid #428BCA;}
  .navigation li {float: left; margin: 0; padding: 0;}
   .navigation li a {padding: 20px 30px; float: left;}
   .navigation li.active a {background: #428BCA; color: #fff;}
 .user-info-block .user-body {float: left; padding: 5%; width: 90%;}
  .user-body .tab-content > div {float: left; width: 100%;}
  .user-body .tab-content h4 {width: 100%; margin: 10px 0; color: #333;}
</style>
	<div class="row">
		<div class="col-md-8">
	<div class="user-info-block">
               <!-- <div class="user-heading">
                    <h3>Karan Singh Sisodia</h3>
                    <span class="help-block">Chandigarh, IN</span>
                </div>-->
                <ul class="navigation">
                    <li class="active">
<a  href="?tab=1">
    <span class="glyphicon glyphicon-user"></span>
</a>
                    </li>
                    <li>
<a  href="?tab=2">
    <span class="fa fa-paw" data-toggle="tooltip" data-placement="top" title="Log aktivitas "></span>
</a>
                    </li>
                    <li>
<a  href="?tab=3" >
    <span class="glyphicon glyphicon-envelope" data-toggle="tooltip" data-placement="top" title="Kirim permintaan "></span>
</a>
                    </li>
                    <li>
<a  href="?tab=4">
    <span class="fa fa-users"></span>
</a>
                    </li>
                    <li>
                      <a href="?tab=5">
<span class="glyphicon glyphicon-link" data-toggle="tooltip" data-placement="top" title="tambah link ke produk "></span>
                      </a>
                    </li>
                </ul>
                <div class="user-body">
                    <div class="tab-content">
<div id="info" class="<?php echo ((isset($_GET['tab'])) && $_GET['tab']==1)? 'tab-pane active': 'tab-pane';?>">
    <table class="table">
      <tr>
        <td colspan="2" class="text-right">
        <?php if (!isset($_GET['edit'])) { ?>
          <a href="<?php echo(current_url().'?tab=1&edit');?>" class="btn btn-sm btn-default">
            <i class="glyphicon glyphicon-pencil">edit</i>
          </a>
        <?php }else{ ?>
        <a href="<?php echo(site_url('gudang/profile?tab=1'));?>" class="btn btn-sm btn-default">
            <i class="glyphicon glyphicon-remove">cancel</i>
        </a>
        <?php }?>
        </td>
      </tr>
      <?php if (!isset($_GET['edit'])) { ?>
        <tr>
        <td>Username :</td>
        <td><?php echo $infouser['username'];?></td>
      </tr>
      <tr>
        <td>User Level :</td>
        <td><?php echo $infouser['jabatan'];?></td>
      </tr>
      <?php 
      
      foreach ($detuser as $vdetu): ?>
      <?php foreach ($likol as $vkol): ?>
        <?php if ($vkol!=='username' && $vkol!=='kdcapab' && $vkol!=='password') {?>
          <tr>
            <td><?php echo($vkol);?></td>
            <td>
            <?php if ($vkol==='website') { 
                  $pchweb=explode(',', $vdetu[$vkol]);
                  $cpchw=count($pchweb);
                  for ($wb=0; $wb < $cpchw; $wb++) { 
                    echo '<a href="'.geturlweb($pchweb[$wb]).'" target="blank">'.geturlweb($pchweb[$wb]) .'</a><br>';
                  }
              }else{ 
                  echo($vdetu[$vkol]);
              }?>
            </td>
          </tr>
        <?php }?>
      <?php endforeach; ?>
      <?php endforeach; ?>
      <?php }else{ 
        
        ?>
      <form action="<?php echo(site_url('gudang/editprof'));?>" name="saveprof" method="post">
      <?php 
      foreach ($detuser as $vdetu) {
      foreach ($likol as $vkol) {?>
      <tr>
        <?php
      switch ($vkol) {
        case 'website': ?>
          <td>
            <label ><?php echo($vkol);?></label>
          </td>
          <td>
          <div class="col-md-4">
            <button class="btn btn-default" type="button" id="btnweb"><span class="glyphicon glyphicon-plus"></span></button>
          </div>
          <div class="col-md-8">
          <div class="form-group">
            <input type="text" class="form-control web" placeholder="nama website" name="namaweb" />
          </div>
          <div class="form-group">
            <input type="text" class="form-control web" placeholder="link website" name="website" />
          </div>
          </div>
          <table class="table table-bordered">
          <thead>
              <tr>
              <td>aksi</td>
              <td>No</td>
              <td>Nama website</td>
              <td>Link website</td>
            </tr>
          </thead>
          <tbody>
          <?php if (($website) && (!empty($website)) ):
          $x=1;
          ?>
            <?php foreach ($website as $vwebsite) { ?>
            <tr>
            <td>
              <a href="<?php echo(site_url('gudang/edit/'.$vwebsite['id'].'/18/id'));?>">edit</a>
              <a href="<?php echo(site_url('gudang/delete/'.$vwebsite['id'].'/18/id'));?>">delete</a>
            </td>
            <td><?php echo($x);?></td>
              <td>
                <?php echo($vwebsite['namaweb']);?>
              </td>
              <td>
                <?php echo($vwebsite['website']);?>
              </td>
            </tr>
            <?php 
            $x++;
            }?>
            <?php else: ?>
            <tr>
              <td>0</td>
              <td colspan="2">belum ada link website</td>
            </tr>
          <?php endif; ?>
          </tbody>
          </table>
          </td>
        <?php   break;
        case 'password':?>
          <td><label ><?php echo($vkol);?></label></td>
          <td>
            <input type="hidden" value="<?php echo($vdetu[$vkol]);?>" id="cocokpass" />
            <div class="form-group">
            <input type="password" name="<?php echo($vkol.'lm');?>" class="form-control" placeholder="password lama" onkeyup="cekpasslama(this.value)">
            <div id="msgcek"></div>
            </div>
            <div class="form-group">
            <input type="password" name="<?php echo($vkol);?>" class="form-control" id="passbaru" placeholder="password baru">
            </div>
          </td>
          <?php break;
        default:?>
        <?php if ($vkol!=='id' && $vkol!=='kdcapab') { ?>
          <td><label ><?php echo($vkol);?></label></td>
          <td><input type="text" name="<?php echo($vkol);?>" id="" class="form-control" value="<?php echo($vdetu[$vkol]);?>"></td>
      <?php } ?>
          <?php break;
      }
      ?>
      </tr>
      <?php }
      } ?>
      <tr>
        <td colspan="2"><input type="submit" name="saveprof" value="save" class="btn btn-lg btn-success"></td>
      </tr>
      </form>
      <?php }?>
    </table>
</div>
<div id="set" class="<?php echo ((isset($_GET['tab'])) && $_GET['tab']==2)? 'tab-pane active': 'tab-pane';?>">
<!--log 00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000-->
<table class="table table-bordered">
<tr>
  <td>No Request</td>
  <td>Waktu</td>
  <td>harga jual</td>
  <td>Nama barang </td>
  <td>Model</td>
  <td>Deskripsi</td>
  <td>Prev gambar</td>
  <td>status</td>
</tr>
<?php if ((count($logreq)===0) || (empty($logreq))) { ?>
  <tr>
    <td colspan="7" class="text-center"> belum ada permintaan</td>
  </tr>
<?php }else{ ?>
<?php foreach ($logreq as $valreq):
?>
  <tr>
    <td><a href="<?php echo(current_url().'/a?idreq='.$valreq['idreq'].'&tbl=16');?>"><?php echo($valreq['idreq']);?></a></td>
    <td><?php echo($valreq['time']);?></td>
    <td><?php echo ((empty($valreq['kdbarang'])) || (is_null($valreq['kdbarang'])) || (strlen($valreq['kdbarang'])===0))? 0 : gethrgbrg($valreq['kdbarang']);?></td>
    <td><?php echo($valreq['namaprod']);?></td>
    <td><?php echo($valreq['Model']);?></td>
    <td><?php echo($valreq['desc']);?></td>
    <td><a href="<?php echo(current_url().'/a?img='.$valreq['idimg'].'&tbl=20');?>"><?php echo(geturl_img($valreq['idimg']));?></a></td>
    <td><?php 
      $larikc=udahnyari($valreq['idreq']);
      if ($larikc) {
        $stantri=getstatusantri($valreq['idreq']);
        foreach ($larikc as $valc) {
            $linkb=$valc['linkbeli'];
            $hrgb=$valc['hrg_beli'];
        }
        if (($hrgb==='0') && (strlen($linkb)===0)) {
          echo('process');
        }else if ((strlen($linkb) > 0)  && ($hrgb==='0')) {
          echo('Waiting');
        }else if (($stantri) && (strlen($stantri) > 0)) {
          echo($stantri);
        }else{
          echo('Waiting Approval');
        }
      }else{
        echo('pending');
      }
    ?></td>
  </tr>
<?php endforeach;?>
<?php  }?>
</table>
<!--log 00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000-->
</div>  
<div id="send" class="<?php echo ((isset($_GET['tab'])) && $_GET['tab']==3)? 'tab-pane active': 'tab-pane';?>">
<?php
$nmaprod='';$kdbrg='';$mdl='';
if (isset($_GET['isi2'])) {
  $kdb=htmlspecialchars($_GET['isi2']);
  $prod=getprod($kdb);
  $nmaprod=$prod[2];$kdbrg=$prod[0];$mdl=$prod[1];
}
?>

<?php
if (isset($_GET['e'])) { ?>
  <div class="alert alert-danger" role="alert"> Maaf terjadi kesalahan saat mengupload gambar pastikan extensi gambar .jpeg , .gif atau .png </div>
<?php } ?>
<form  enctype="multipart/form-data" class="form-horizontal" action="<?php echo(site_url('gudang/insert'))?>" method="post">
<input type="hidden" value="15" name="tabel">
  <div class="form-group">
    <label for="" class="col-sm-2 control-label">Nama Produk</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" placeholder="isikan nama produk" name="namaprod">
    </div>
  </div>
    <div class="form-group">
    <label for="" class="col-sm-2 control-label">Model Produk</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="Model" placeholder="isikan model produk" name="Model" value="<?php echo($mdl);?>">
    </div>
    </div>
  <div class="form-group">
    <label for="" class="col-sm-2 control-label">Description produk</label>
    <div class="col-sm-10">
      <textarea name="desc" class="form-control" placeholder="isikan deskripsi produk"></textarea>
    </div>
  </div>
   <div class="form-group">
    <label for="" class="col-sm-2 control-label">Spesifikasi produk</label>
    <div class="col-sm-10">
    <textarea name="ket" class="form-control" placeholder="isikan spesifikasi produk"></textarea>
    </div>
  </div>
<!-- upload  -->
<?php include APPPATH.'views/fields/uploadimg.php';?>
<!-- -->
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">kirim</button>
    </div>
  </div>
</div>
<div id="cus" class="<?php echo ((isset($_GET['tab'])) && $_GET['tab']==4)? 'tab-pane active': 'tab-pane';?>">
     <form action="" method="">
<table class="table">
  <tr>
    <td>aksi</td>
    <td>ID Customer</td>
    <td>Customer Name</td>
  </tr>
  <?php 
  if($listcus){ ?>
  <?php foreach ($listcus as $vcus) { ?>
    <tr>
      <td>
      <div class="btn-group" role="group" aria-label="...">
        <a href="<?php echo(site_url('gudang/slug/5/1/7?isi='.$vcus['idcus']));?>" class="btn btn-sm btn-primary">Quotation</a>
        <a href="<?php echo(site_url('gudang/slug/5/1/7?isi='.$vcus['idcus']));?>" class="btn btn-sm btn-primary">Invoice</a>
      </div>
      </td>
      <td><a href="<?php echo(site_url('gudang?id='.$vcus['idcus'].'&tbl=1'))?>"><?php echo($vcus['idcus']);?></a></td>
      <td><?php echo($vcus['nama']);?></td>
    </tr>
  <?php }?>
  <?php }else{ ?>
  <tr>
    <td colspan="3" class="alert alert-warning" role="alert">
      anda belum mendaftarkan pelanggan :(
    </td>
  </tr>
  <?php } ?>
</table>
</form>
</div>


                    <div id="info" class="<?php echo ((isset($_GET['tab'])) && $_GET['tab']==5)? 'tab-pane active': 'tab-pane';?>">
                    <table class="table table-bordered"> 
                    <thead>
                    <tr>
                      <td>kode barang</td>
                      <td>website</td>
                      <td>link post</td>
                      <td>time created</td>
                    </tr>
                    </thead>
                    <tbody>
                      <?php
                      if (($postprod) && (!empty($postprod))) { 
                        foreach ($postprod as $vprod) {?>
                            <tr>
                              <td><a href="<?php echo(site_url('gudang/profile/wew?tab=5&id='.$vprod['kdbarang'].'&tbl=3'))?>"><?php echo($vprod['kdbarang'])?></a>
                              <input type="hidden" value="<?php echo($vprod['kdbarang']);?>" />
                              </td>
                              <td><?php echo(geturlweb($vprod['website']));?></td>                              
                              <td><a href="<?php echo($vprod['link']);?>" target="blank"><?php echo($vprod['link']);?></a></td>
                              <td><?php echo($vprod['time']);?></td>
                            </tr>
                        <?php } ?>
                    <?php }else{ ?>
                        <tr>
                          <td colspan="4">belum ada produk yang terkait LINK :(</td>
                        </tr>
                  <?php } ?>
                    </tbody>
                    </table>
                    <hr>
                    <form action="<?php echo(site_url('gudang/insert'))?>" method="post">
                    <input type="hidden" name="tabel" value="17">
                      <div class="form-group">
                          <label for="nmprod">Nama produk / Description</label>
                          <?php include APPPATH.'views/fields/kdbarang.php'; ?>
                      </div>
                      <span id="txtHprod">
                      </span>
                      <div class="form-group">
                      <label>Nama Website</label>
                      <?php if ($website) {?>
                        <select class="form-control" name="website">
                        <?php foreach ($website as $vweb) { ?>
                            <option value="<?php echo($vweb['id']);?>"><?php echo($vweb['namaweb'])?></option>
                        <?php }?>
                        </select>
                      <?php }else{?>
                      <span class="alert alert-warning" role="alert ">anda belum mendaftarkan website</span>
                      <?php } ?>
                      </div>
                      <div class="form-group">
                      <label>Link postingan produk</label>
                      <input type="text" name="link" class="form-control">
                      </div>
                      <input type="submit" value="create" class="btn btn-lg btn-success" />
                    </form>
                    </div>

                    </div>
                </div>
            </div>

</div>
<div class="col-md-4"></div>
</div>
