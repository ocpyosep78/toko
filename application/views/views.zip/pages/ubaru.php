<h1 style="color:#000000;">hello <?php echo(isset($_GET['u']))? getuname(htmlspecialchars($_GET['u'])) : 'anonymous';?></h1>
<br>
<p>
	Terima kasih sudah bergabung bersama kami selanjutnya , tunggu konfirmasi dari admin
	untuk penerimaan anggota resmi :) , Terima kasih
</p>

