<div class="container">
	<div class="row">
		<div class="cl-xs-12">
			<div class="panel-warning">
				silahkan buat database bernama 'toko' !
			</div>
		</div>
	</div>
</div>
